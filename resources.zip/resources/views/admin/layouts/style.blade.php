<link rel="icon" type="image/x-icon" href="{{asset('./assets/img/favicon.jpg')}}">
<link href="{{asset('./assets/vendors/bootstrap/dist/css/bootstrap.min.css')}}" rel="stylesheet" />
<link href="{{asset('./assets/vendors/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet" />
<link href="{{asset('./assets/vendors/themify-icons/css/themify-icons.css')}}" rel="stylesheet" />
<!-- PLUGINS STYLES-->
<link href="{{asset('./assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css')}}" rel="stylesheet" />
<link href="{{asset('./assets/vendors/DataTables/datatables.min.css')}}" rel="stylesheet" />
<link href="{{asset('./assets/css/toastr.min.css')}}" rel="stylesheet" />
<link href="{{asset('./assets/css/bootstrap-datepicker3.min.css')}}" rel="stylesheet" />
<link href="{{asset('./assets/css/select2.min.css')}}" rel="stylesheet" />
<!-- THEME STYLES-->
<link href="{{asset('./assets/css/main.min.css')}}" rel="stylesheet" />

<style>
    .error-text{
        margin-left: 170px
    }
</style>
