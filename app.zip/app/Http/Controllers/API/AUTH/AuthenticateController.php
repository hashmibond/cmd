<?php

namespace App\Http\Controllers\API\AUTH;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\AUTH\ForgotPasswordRequest;
use App\Http\Requests\API\AUTH\LoginRequest;
use App\Http\Requests\API\AUTH\ResetPasswordRequest;
use App\Models\RegisterAccessToken;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthenticateController extends Controller
{

    public function login(LoginRequest $request)
    {
        try {
            $user= User::Where('email',$request->identifier)->first();
            /*----------------------for email login------------------------*/
            if ($user && $user->role_id==3){
                $credentials=['email' => $request->identifier, 'password' => $request->password,];
                if(!Auth::attempt($credentials)){
                    return response()->json([
                        'status' => false,
                        'message' => 'These credentials do not match our records.',
                    ], 401);
                }
                return response()->json([
                    'status' => true,
                    'message' => 'User Logged In Successfully',
                    'access_token' => $user->createToken('auth_token',['*'],now()->addMinutes(180))->plainTextToken,
                    'token_type' => 'Bearer',
                    'data' => $user,
                ], 200);
            }
            /*----------------------for phone login------------------------*/
            $user= User::Where('phone',$request->identifier)->first();
            if ($user && $user->role_id==3){
                $credentials=['email' => $user->email, 'password' => $request->password,];
                if(!Auth::attempt($credentials)){
                    return response()->json([
                        'status' => false,
                        'message' => 'These credentials do not match our records.',
                    ], 401);
                }
                return response()->json([
                    'status' => true,
                    'message' => 'User Logged In Successfully',
                    'access_token' => $user->createToken('auth_token',['*'],now()->addMinutes(180))->plainTextToken,
                    'token_type' => 'Bearer',
                    'data' => $user,
                ], 200);
            }

            return response()->json([
                'status' => false,
                'message' => 'These credentials do not match our records.',
            ], 401);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function logout(Request $request)
    {
        try {
            Auth::user()->tokens()->where('id', Auth::user()->currentAccessToken()->id)->delete();
            return response()->json([
                'status' => true,
                'message' => 'User Logged Out Successfully',
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function forgotPassword(ForgotPasswordRequest $request)
    {
        try {
            $user_info=User::where('phone', $request->phone)->first();
            if (!$user_info){
                return response()->json([
                    'status' => false,
                    'message' => 'user not found'
                ], 404);
            }
            RegisterAccessToken::where('phone', $request->phone)->delete();
            $token=Str::random(40);
            $otp=rand(1000,9999);
            $forgot_credentials=RegisterAccessToken::create([
                'phone' => $request->phone,
                'token' => $token,
                'otp' => $otp
            ]);

            return response()->json([
                'status' => true,
                'data' => $forgot_credentials,
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => 'something went wrong'
                /*'message' => $th->getMessage()*/
            ], 500);
        }
    }

    public function resetPassword(ResetPasswordRequest $request)
    {
        try {
            $auth_info=RegisterAccessToken::where('phone', $request->phone)->first();
            if (!$auth_info || $auth_info->token!=$request->token || $auth_info->otp!=$request->otp){
                return response()->json([
                    'status' => false,
                ], 401);
            }
            $user=User::where('phone', $request->phone)->first();
            $user->password = Hash::make($request->password);
            $user->update();
            $auth_info->delete();
            return response()->json([
                'status' => true,
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => 'something went wrong'
                /*'message' => $th->getMessage()*/
            ], 500);
        }
    }
}
