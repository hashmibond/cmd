<?php


if (!function_exists('baseUrl')) {
    function baseUrl() {
        return 'https://cmd.bondstein.xyz';
    }
}
